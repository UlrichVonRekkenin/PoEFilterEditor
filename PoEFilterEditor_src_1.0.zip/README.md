Good day,

I coded a simple friendly "PoE Filter Editor". You may get it [url=here].
You can load and simply edit another *.filter scripts
(easy navigation through thousands script lines), just loading it.
Comments will be stored.
Rem.: for correct parsing the structure of your blocks should be like that:
  Show
  # some comments
      BaseType Gem
      Qualilty > 10

Requirements:
1) download [url=python3] and install it;
2) and [url=PyQt4] for GUI, too;
3) Win or Linux/Unix.

Launch:
Install, copy files main.pyw and filter_gui.ui to
the $PoEDir\Scripts\FilterEditor, for example.
Right-click on main.pyw -> Properties and choose application to run (for me C:\Python34\pythonw.exe).
Done. Easy ;)

Shortcuts:
Ctrl+O: Open files (*.json for previously project or *.filter for another one);
Ctrl+S: Save project to *.json file and if something was generated to *.filter with the same name.
Ctrl+A: Add current block;
Ctrl+R: Update current block;
Ctrl+D: Delete current block;
Ctrl+F: Find all matched words in a generated scripts and underline it by red line;
F3: move to the next match;
Ctrl+Enter: Generate PoE item filter script.
